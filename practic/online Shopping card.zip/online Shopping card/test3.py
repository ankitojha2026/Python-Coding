l=[1,2,3,4,5]
l1=l
print(id(l1))
print(id(l))
