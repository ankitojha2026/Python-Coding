a=1
a=a+1
print(a)