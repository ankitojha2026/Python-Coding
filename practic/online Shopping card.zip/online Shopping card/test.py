from prettytable import PrettyTable
#initilization the column name
l=[[0,1,2],[0,3,4],[1,2,3]]
for i in range(len(l)):
    print(i)

#add row
'''def printCardItem():
    cardTable=PrettyTable(["Selected ID","Item Name","Price/1qt","Quantity","Total"])
    for i in range(len(3)):
        cardTable.add_row(i)
    print(cardTable)'''